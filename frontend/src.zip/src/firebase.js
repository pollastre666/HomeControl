// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDvVBx0r8MxX6xNe-dHdsvPdzOaORcuEk0",
  authDomain: "homecontrol-dac34.firebaseapp.com",
  projectId: "homecontrol-dac34",
  storageBucket: "homecontrol-dac34.firebasestorage.app",
  messagingSenderId: "860531471097",
  appId: "1:860531471097:web:ed0f6c8638e36226092828"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);